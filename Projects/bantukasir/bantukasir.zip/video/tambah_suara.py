#!/usr/bin/env python3
"""
Tambah narasi suara (bahasa Indonesia) ke video BantuKasir_Explainer_2D.mp4

Kebutuhan (sekali saja):
    1. Python 3.9+   2. ffmpeg terpasang (perintah `ffmpeg` bisa dijalankan)
    3. pip install edge-tts      (butuh internet saat membuat suara)

Pemakaian:
    python tambah_suara.py BantuKasir_Explainer_2D.mp4
Hasil:
    BantuKasir_Explainer_2D_suara.mp4  (video + narasi)
    narasi_mix.m4a                     (audio saja, kalau mau diedit di CapCut dll.)
"""
import asyncio, json, subprocess, sys, os, shutil

# ---------- PENGATURAN (silakan ubah) ----------
VOICES = {                      # pengisi suara per peran
    "narator":   dict(voice="id-ID-ArdiNeural",  rate="+0%",  pitch="+0Hz"),
    "pemilik":   dict(voice="id-ID-GadisNeural", rate="+0%",  pitch="+0Hz"),   # Bu pemilik warung
    "pelanggan": dict(voice="id-ID-ArdiNeural",  rate="+6%",  pitch="+8Hz"),   # Kak pelanggan
}
LEAD_IN  = 0.35   # detik jeda sebelum bicara di tiap scene
TAIL     = 0.45   # detik sisa di akhir scene
MAX_SPEEDUP = 1.35  # kalau kalimat kepanjangan, dipercepat paling banyak sekian kali
FAKE = os.environ.get("FAKE_TTS") == "1"   # hanya untuk uji coba tanpa internet
# -----------------------------------------------

SCENES = json.loads(r'''[{"i": 0, "start": 0, "end": 7, "text": "Jam enam pagi, warung Bu Siti buka. Hari ini untung berapa, ya?", "pitch": null}, {"i": 1, "start": 7, "end": 14, "text": "Dulu, catat di buku. Lupa satu. Salah hitung.", "pitch": null}, {"i": 2, "start": 14, "end": 22, "text": "Kenalkan, BantuKasir. Tahu untung hari ini, sebelum warung tutup. Langsung dari browser, tanpa unduh.", "pitch": null}, {"i": 3, "start": 22, "end": 31, "text": "Buka berandanya, insight hari ini langsung menjelaskan. Untung enam puluh satu ribu, naik dari kemarin, lengkap dengan penyebab dan saran stok.", "pitch": null}, {"i": 4, "start": 31, "end": 43, "text": "Catat jualan di Kasir. Ketuk produk, cek keranjang, pilih tunai atau QRIS, lalu simpan. Penjualan tersimpan, struk jadi.", "pitch": null}, {"i": 5, "start": 43, "end": 51, "text": "Produk dan stok tertata rapi. Mau tambah produk baru? Cukup isi nama dan foto.", "pitch": null}, {"i": 6, "start": 51, "end": 57, "text": "Selamat siang, Kak! Mau pesan apa? Scan barcode di meja ini ya, tidak perlu antre.", "pitch": 0.95}, {"i": 7, "start": 57, "end": 62, "text": "Oke, Bu. Saya scan barcode-nya dulu.", "pitch": 1.4}, {"i": 8, "start": 62, "end": 70, "text": "Menu Warung Tiga D langsung terbuka. Saya pilih ayam goreng dan matcha latte. Totalnya tiga puluh ribu.", "pitch": 1.4}, {"i": 9, "start": 70, "end": 79, "text": "Atau lebih praktis lagi, tekan Pesan dengan Suara, lalu bilang: ayam goreng satu, kopi hitam satu. Keranjang langsung terisi, totalnya dua puluh ribu.", "pitch": 1.4}, {"i": 10, "start": 79, "end": 85, "text": "Lalu isi nama saya, Muh Rofi Basri, dan tekan Kirim Pesanan.", "pitch": 1.4}, {"i": 11, "start": 85, "end": 92, "text": "Pesanan nomor dua satu delapan sudah masuk di kasir saya. Pembayaran lewat QRIS, ya, Kak.", "pitch": 0.95}, {"i": 12, "start": 92, "end": 97, "text": "Sudah, Bu! Pembayaran selesai. Terima kasih!", "pitch": 1.4}, {"i": 13, "start": 97, "end": 101, "text": "Terima kasih, Kak! Pesanannya segera saya antar.", "pitch": 0.95}, {"i": 14, "start": 101, "end": 114, "text": "Laporan lengkap: pendapatan, laba bersih, grafik tujuh hari, penjualan per kategori, modal dan biaya, sampai produk terlaris.", "pitch": null}, {"i": 15, "start": 114, "end": 123, "text": "Semua transaksi tercatat di riwayat. Atur nama usaha, QRIS toko, dan pajak sesuai kebutuhan.", "pitch": null}, {"i": 16, "start": 123, "end": 129, "text": "Ada pelanggan yang utang? Catat di kasbon, semuanya tercatat rapi.", "pitch": null}, {"i": 17, "start": 129, "end": 135, "text": "Daftar gratis, tanpa unduh, di bantukasir titik biz titik id.", "pitch": null}]''')

def role(pitch):
    if pitch is None: return "narator"
    return "pemilik" if pitch < 1 else "pelanggan"

def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def dur(path):
    out = subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration",
                                   "-of","default=nw=1:nk=1",path])
    return float(out)

async def make_tts(i, text, cfg, path):
    if FAKE:
        run(["ffmpeg","-y","-f","lavfi","-i",f"sine=frequency={300+40*i}:duration={len(text)*0.075:.2f}",path]); return
    import edge_tts
    await edge_tts.Communicate(text, cfg["voice"], rate=cfg["rate"], pitch=cfg["pitch"]).save(path)

async def main(video):
    if not shutil.which("ffmpeg"): sys.exit("ffmpeg belum terpasang.")
    os.makedirs("audio_tmp", exist_ok=True)
    inputs, filters, labels = [], [], []
    for n, s in enumerate(SCENES):
        text = s["text"]; cfg = VOICES[role(s["pitch"])]
        raw = f"audio_tmp/s{s['i']:02d}.mp3"
        await make_tts(s["i"], text, cfg, raw)
        d = dur(raw); room = (s["end"]-s["start"]) - LEAD_IN - TAIL
        speed = 1.0
        if d > room: speed = min(MAX_SPEEDUP, d/room)
        flag = "  <-- dipercepat" if speed > 1 else ""
        print(f"scene {s['i']:02d} [{role(s['pitch']):9s}] {d:5.1f}s / ruang {room:4.1f}s  x{speed:.2f}{flag}")
        if d/speed > room+0.05:
            print(f"   ! scene {s['i']:02d} masih kepanjangan; persingkat teks atau naikkan MAX_SPEEDUP")
        inputs += ["-i", raw]
        ms = int((s["start"]+LEAD_IN)*1000)
        f = f"[{n}:a]"
        if speed > 1: f += f"atempo={speed:.3f},"
        f += f"aformat=sample_rates=44100:channel_layouts=mono,adelay={ms}|{ms}[a{n}]"
        filters.append(f); labels.append(f"[a{n}]")
    total = SCENES[-1]["end"]
    filters.append("".join(labels)+f"amix=inputs={len(labels)}:normalize=0:dropout_transition=0,"
                   f"loudnorm=I=-16:TP=-1.5:LRA=11,apad=whole_dur={total},atrim=0:{total}[out]")
    run(["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map","[out]",
         "-c:a","aac","-b:a","192k","narasi_mix.m4a"])
    base, _ = os.path.splitext(video)
    outv = base + "_suara.mp4"
    run(["ffmpeg","-y","-i",video,"-i","narasi_mix.m4a","-map","0:v","-map","1:a",
         "-c:v","copy","-c:a","aac","-b:a","192k","-movflags","+faststart","-shortest",outv])
    print("\nSelesai ->", outv)

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    asyncio.run(main(sys.argv[1]))