export const nanoid = (size = 10) => {
const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let id = '';
for (let i = 0; i < size; i++) id += chars[Math.floor(Math.random() * chars.length)];
return id;
};